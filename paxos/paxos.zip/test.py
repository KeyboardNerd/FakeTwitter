import config
import model
import message
import reliablestorage as d

config.load_sites("config.json")
config.my_site = config.all_sites[0]

